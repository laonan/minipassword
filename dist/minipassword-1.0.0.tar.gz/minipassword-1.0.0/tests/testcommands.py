# just python tests/testcommands.py
from minipassword.commands import CommandHandler
h = CommandHandler()
h.run()
